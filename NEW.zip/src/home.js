// import axios from "axios";
// import React, { useCallback, useState } from "react";
// import { useDropzone } from "react-dropzone";
// import "./App.css"; // Create App.css for your styles

// function Home() {
//     const [uploadedFiles, setUploadedFiles] = useState([]);
//     console.log("uploadedFiles1", uploadedFiles)
//     const onDrop = useCallback(async (acceptedFiles) => {
//         setUploadedFiles([...uploadedFiles, ...acceptedFiles]);
//     }, [uploadedFiles]);
//     const fileNames = uploadedFiles.map(file => file.name);
//     console.log("fileNames", fileNames)
//     const req = {
//         images: fileNames,
//     };
//     console.log("req", req)
//     const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

//     const cartonize = () => {
//         axios.post("http://192.168.2.114:7000/Api/upload/", req, {
//             headers: {
//                 "Content-Type": "multipart/form-data",
//             },
//         }).then((response) => {
//             console.log("API response", response);
//         })
//     }

//     return (
//         <>
//             <div style={{ padding: "2rem", backgroundColor: "black", height: "100vh" }}>
//                 <div style={{ textAlign: "center" }}>
//                     <h2 style={{ fontSize: "2rem", paddingBottom: "1rem", color: "white" }}>White Box Cartoonization</h2>
//                 </div>
//                 <div className="container">
//                     <div className="row">
//                         <div className="col-lg-6">
//                             <div className="card">
//                                 <div style={{ display: "flex" }}>
//                                     <div
//                                         {...getRootProps()}
//                                         className={`upload-btn ${isDragActive ? "active" : ""}`}
//                                     >
//                                         <input {...getInputProps()} />
//                                         {isDragActive ? "Drop the files here" : "Click to Upload Images"}
//                                     </div>
//                                     <div className="convert">
//                                         <button onClick={() => { cartonize() }} >Cartoonise</button>
//                                     </div>
//                                 </div>
//                                 <div className="file-list">
//                                     {uploadedFiles.map((file, index) => (
//                                         <div key={index} className="file-item">
//                                             <img
//                                                 src={URL.createObjectURL(file)}
//                                                 alt={`Uploaded ${index}`}
//                                                 className="thumbnail"
//                                             />
//                                             <span className="file-name">{file.name}</span>
//                                         </div>
//                                     ))}
//                                 </div>
//                             </div>
//                         </div>
//                         <div className="col-lg-6">
//                             <div className="card">
//                                 <h2 style={{ fontSize: "2rem", textAlign: "center" }}>Cartoonized Images</h2>
//                             </div>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </>

//     );
// }

// export default Home;


import axios from "axios";
import React, { useCallback, useState, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import "./App.css"; // Create App.css for your styles

function Home() {
    const [uploadedFiles, setUploadedFiles] = useState([]);
    console.log("uploadedFiles", uploadedFiles)
    const onDrop = useCallback((acceptedFiles) => {
        setUploadedFiles((prevUploadedFiles) => [...prevUploadedFiles, ...acceptedFiles]);
    }, []);


    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });




    const cartonize = () => {

        const fileNames = uploadedFiles.map((file) => file.name);
        const fileNamesString = fileNames.join(","); // Convert the array to a comma-separated string
        console.log(fileNamesString, "fileNamesString")

        const formData = new FormData();
        // formData.append("images", fileNamesString);
        formData.append('images',uploadedFiles[0].name)

        console.log(formData, "formData")

        axios.post("http://192.168.2.114:7000/Api/upload/", formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        })
            .then((response) => {
                console.log("API response", response);
            })
            .catch((error) => {
                console.error("API error", error);
            });

    };

    return (
        <>
            <div style={{ padding: "2rem", backgroundColor: "black", height: "100vh" }}>
                <div style={{ textAlign: "center" }}>
                    <h2 style={{ fontSize: "2rem", paddingBottom: "1rem", color: "white" }}>White Box Cartoonization</h2>
                </div>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="card">
                                <div style={{ display: "flex" }}>
                                    <div
                                        {...getRootProps()}
                                        className={`upload-btn ${isDragActive ? "active" : ""}`}
                                    >
                                        <input {...getInputProps()} />
                                        {isDragActive ? "Drop the files here" : "Click to Upload Images"}
                                    </div>
                                    <div className="convert">
                                        <button onClick={() => { cartonize() }}>Cartoonise</button>
                                    </div>
                                </div>
                                <div className="file-list">
                                    {uploadedFiles.map((file, index) => (
                                        <div key={index} className="file-item">
                                            <img
                                                src={URL.createObjectURL(file)}
                                                alt={`Uploaded ${index}`}
                                                className="thumbnail"
                                            />
                                            <span className="file-name">{file.name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6">
                            <div className="card">
                                <h2 style={{ fontSize: "2rem", textAlign: "center" }}>Cartoonized Images</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Home;
